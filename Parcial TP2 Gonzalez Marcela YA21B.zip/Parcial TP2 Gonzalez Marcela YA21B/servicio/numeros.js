import ModelMem from '../model/DAO/numerosMem.js'


class Servicio {
    constructor() {
        this.model = new ModelMem()
    }

    obtenerNumeros = () => {
        const numeros = this.model.obtenerNum()
        const arrayNumeros= numeros.map((obj) => obj.num);
        return arrayNumeros
    }  

    obtenerPromedioNum = () => {
        const numeros = this.model.obtenerNum()
        let sumaNumeros = numeros.reduce((acumulador,numeros)=>acumulador +numeros.num,0)
        const promedioNumeros = sumaNumeros / numeros.length
        return Number(promedioNumeros)
    } 

    obtenerMinMax = () => {
        const numeros = this.model.obtenerNum()
        const numMax = numeros.sort((a,b) => b.num - a.num)[0]
        const numMin = numeros.sort((a,b) => a.num - b.num)[0]
        const numeroMax= numMax.num
        const numeroMin= numMin.num
        const numMinMax = {numeroMax,numeroMin}
        return numMinMax
    } 

    obtenerCantNumeros = () => {
        const numeros = this.model.obtenerNum()
        return numeros.length
    }  

    guardarNumero = num => {
        const numeroGuard = this.model.guardarNumero(num)
        return numeroGuard
    }

}

export default Servicio