class ModelMem {
    constructor() {
        this.numeros = [
        ]
    }

    obtenerNum = () => {    
        return this.numeros
    }

    guardarNumero = num => {        
        num.num = Number(num.num)
        this.numeros.push(num)
        return num
    }

}

export default ModelMem