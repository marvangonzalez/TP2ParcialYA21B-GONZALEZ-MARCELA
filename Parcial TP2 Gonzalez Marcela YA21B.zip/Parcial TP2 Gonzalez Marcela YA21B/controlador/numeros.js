import Servicio from '../servicio/numeros.js'


class Controlador {
    constructor() {
        this.servicio = new Servicio()
    }

    obtenerNumeros = (req,res) => {
        const numeros = this.servicio.obtenerNumeros()
        res.json({numeros})
    }

    
    obtenerPromedioNumeros = (req,res) => {
        const numProm = this.servicio.obtenerPromedioNum()
        res.json({promedio: numProm})
    }

    obtenerMinMax = (req,res) => {
        const numMinMax = this.servicio.obtenerMinMax()
        res.json({min: numMinMax.numeroMax, max: numMinMax.numeroMin})
    }

    obtenerCantNumeros = (req,res) => {
        const numeros = this.servicio.obtenerCantNumeros()
        res.json({cantidad: numeros})
    }

    guardarNumero = (req,res) => {
        const numero = req.body
        const numeroGuard = this.servicio.guardarNumero(numero)
        res.json(numeroGuard)
    }

}

export default Controlador
